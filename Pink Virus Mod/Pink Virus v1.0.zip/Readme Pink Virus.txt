***HOW TO INSTALL***
1. Install Forge (See My Tutorial Here: http://www.youtube.com/watch?v=MNMyuppFfvw)
2. Place This ENTIRE .zip Folder Into Your Mods Folder
3. Start Minecraft...(Have Fun!)
*WARNING* If you care about a world you place this block on, you won't for much longer...just saying.




***BackStory***
It is the Version 1.5.2 A.O.R (After Official Release) In The Land Of Minecraftia, Scientists meddling with some of the most rare
and dangerous materials in Minecraftia have accidentally made the most evil block known to all players, The Pink Virus...(Dun Dun Dun!)
This block has been named because of its evil like nature, it spreads , never stopping, to all blocks and all biomes, and is very hard to destroy, no one is safe.
The Scientists who created this grabbed the logs on their experiments (Where i got the information to write this story), and the recipe
they used to create this monstrocity (They highly discourage making this, of obvious reasons) and blew their base sky high, destroying all remenants of the Virus.
Now I entrust this to you, knowing you are responsible enough to handle this power, to do what you please with this "Pink Virus"...



***Crafting***

	ABA
	CDC
	BBB
		A=Lava Bucket
		B=Obsidian
		C=Emerald Block
		D=Diamond Block
